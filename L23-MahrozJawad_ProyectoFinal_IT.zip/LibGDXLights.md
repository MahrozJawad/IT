<!-- .slide: data-background="lightblue" -->
---
# LibGDX Lights
---

![](SnakeLight.png)

<!-- .slide: data-background="lightblue" -->
---
## What is LibGDX Lights?
---

- It is a library, In which you can create lights around the objects or if you want to produce light on the game Screen, Its will be the best option to use in your project.

<!-- .slide: data-background="lightblue" -->
---
## BOX2D LIGHTS BASIC CONCEPTS
---
- RayHandler
- ConeLight
- PointLight 
- DirectionalLight
- ChainLight

<!-- .slide: data-background="lightblue" -->
---
## RayHandler
---
- Its ia a class which handles updating, disposing and rendering  the lights in gameScreen.

<!-- .slide: data-background="lightblue" -->
---
## PointLigh
---
- Its usually produces the circle an simulate a point of lights. 

<!-- .slide: data-background="lightblue" -->
---
## ConeLight
---
- In the heading it shows that the name comes from cone, it makes sense that will produce the light in the shape of cone. for this its called "ConeLight"

<!-- .slide: data-background="lightblue" -->
---
## DirectionalLight
---
- Directional light shows the lights to a unique location towards through. We can produce lights in different directions. it means everywhere.

<!-- .slide: data-background="lightblue" -->
---
## ChainLight
---
- The name shows that it produce the light in chain.

<!-- .slide: data-background="lightblue" -->
---
# Thanks
---
#### Mahroz Jawad 2ºDAM
---