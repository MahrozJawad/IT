# BasicProject1920
Basic LibGDX project for PMDM IT2 activities
