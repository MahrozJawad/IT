package com.pmdm1920.game;

import com.badlogic.gdx.Game;

public class Snake extends Game {
	
	@Override
	public void create () { 
		setScreen(new GameScreen());
	}
}